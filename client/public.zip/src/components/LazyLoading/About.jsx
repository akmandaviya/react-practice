import React from 'react'

const About = () => {
    console.log("about loaded")
  return (
    <div>
      <h2>Child Page</h2>
      <p>This page was lazy loaded.</p>
    </div>
  )
}

export default About